import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { UserregisterService } from './userregister.service';

describe('UserregisterService', () => {
  let service: UserregisterService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports :[HttpClientTestingModule]
    });
    service = TestBed.inject(UserregisterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
