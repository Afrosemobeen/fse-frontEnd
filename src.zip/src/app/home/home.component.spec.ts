import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { of } from 'rxjs';
import { MoviesService } from '../services/movies.service';

import { HomeComponent } from './home.component';

describe('HomeComponent', () => {
  let component: HomeComponent;
  let movieList=MoviesService;
  let fixture: ComponentFixture<HomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HomeComponent],
      imports :[HttpClientTestingModule, ReactiveFormsModule, FormsModule]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call ngOnInit error..', ()=>{
    let service = fixture.debugElement.injector.get(movieList);
    spyOn(service, 'displayProducts').and.callFake(()=>{
        return of({
          message:'reset password email sent succesfully'
        })
      })
    let spy =spyOn(component, 'ngOnInit').and.callThrough();
    component.ngOnInit();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })

  it('should call bookTicket error..', ()=>{
    
    let spy =spyOn(component, 'bookTicket').and.callThrough();
    component.bookTicket('string');
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })

  it('should call searchProduct error..', ()=>{
    component.movies=[{title:'abc'}]
    let spy =spyOn(component, 'searchProduct').and.callThrough();
    component.searchProduct();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled(); 
  })
});
