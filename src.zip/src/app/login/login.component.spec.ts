import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { of, throwError } from 'rxjs';
import { UserregisterService } from '../services/userregister.service';

import { LoginComponent } from './login.component';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let logindata = UserregisterService
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LoginComponent],
      imports :[HttpClientTestingModule, ReactiveFormsModule,FormsModule]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call userLogin error..', ()=>{
    // component.cartItem=[{}]
    let service = fixture.debugElement.injector.get(logindata);
    spyOn(service, 'userLogin').and.returnValue(throwError({status:422}))
     
    let spy =spyOn(component, 'userLogin').and.callThrough();
    component.userLogin();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })

  it('should call userLogin error..', ()=>{
    // component.cartItem=[{}]
    let service = fixture.debugElement.injector.get(logindata);
    spyOn(service, 'userLogin').and.callFake(()=>{
        return of({
          statusCode:200
        })
      })
    let spy =spyOn(component, 'userLogin').and.callThrough();
    component.userLogin();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })

  it('should call userLogin error..', ()=>{
    // component.cartItem=[{}]
    let service = fixture.debugElement.injector.get(logindata);
    spyOn(service, 'userLogin').and.callFake(()=>{
        return of({
          message:'logged in succesfully'
        })
      })
    let spy =spyOn(component, 'userLogin').and.callThrough();
    component.userLogin();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })

  it('should call userLogin error..', ()=>{
    component.user.controls['role'].setValue('user')
    let service = fixture.debugElement.injector.get(logindata);
    spyOn(service, 'userLogin').and.callFake(()=>{
        return of({
          message:'logged in succesfully',
          user:{}
        })
      })
    let spy =spyOn(component, 'userLogin').and.callThrough();
    component.userLogin();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })
});
